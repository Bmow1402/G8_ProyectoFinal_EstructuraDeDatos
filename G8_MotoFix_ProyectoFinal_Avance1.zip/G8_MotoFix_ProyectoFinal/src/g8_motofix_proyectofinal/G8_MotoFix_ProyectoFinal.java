package g8_motofix_proyectofinal;

import javax.swing.JOptionPane;

public class G8_MotoFix_ProyectoFinal {

    public static void main(String[] args) {
        MenuPrincipal menu = new MenuPrincipal();
        menu.mostrarMenu();
    }
}

/*
========== ESTRUCTURA PARA LOS MENUS DE TALLER MOTOFIX ==========

----- Catálogos -----
1. Catálogo de Clientes
2. Catálogo de Mecanicos
3. Catálogo de Personal Administrativo
4. Catálogo de Motocicletas
5. Catalogo de Servicios
6. Volver al menú principal

--- Catálogo de Clientes ---
1. Agregar Cliente
2. Editar Cliente
3. Inactivar Cliente
4. Mostrar Clientes
5. Volver

--- Catálogo de Mecanicos ---
1. Agregar Mecanico
2. Editar Mecanico
3. Inactivar Mecanico
4. Mostrar Mecanicos
5. Volver

--- Catálogo de Personal Administrativo ---
1. Agregar Personal Administrativo
2. Editar Personal Administrativo
3. Inactivar Personal Administrativo
4. Mostrar Personal Administrativo
5. Volver

--- Catálogo de Motos ---
1. Agregar Motocicleta
2. Editar Motocicleta
3. Inactivar Motocicleta
4. Mostrar Motocicletas
5. Volver

--- Catálogo de Servicios ---
1. Agregar Servicio
2. Editar Servicio
3. Inactivar Servicio
4. Mostrar Servicios
5. Volver

PUNTOS A MEJORA

- Arreglar los metodos de los usuarios para cada catalogo
editar la estructura del codigo para que este mas ordenado

*/
